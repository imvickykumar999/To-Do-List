from flask import Flask, render_template, request, jsonify, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///tasks.db'
db = SQLAlchemy(app)

# Define Task model
class Task(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    is_completed = db.Column(db.Boolean, default=False)
    user_id = db.Column(db.Integer)

# Index route
@app.route('/')
def index():
    return render_template('index.html')

# Get tasks for a specific user
@app.route('/get_tasks', methods=['GET'])
def get_tasks():
    # Replace with user_id logic, here we just assume a user_id = 1 for demo purposes
    tasks = Task.query.filter_by(user_id=1).order_by(Task.is_completed).all()
    tasks_json = [{'id': task.id, 'name': task.name, 'is_completed': task.is_completed} for task in tasks]
    return jsonify({'tasks': tasks_json})

# Add task
@app.route('/add_task', methods=['POST'])
def add_task():
    task_name = request.form.get('name')
    if task_name:
        new_task = Task(name=task_name, user_id=1)  # Replace 1 with actual user logic
        db.session.add(new_task)
        db.session.commit()
        return jsonify({'task': {'id': new_task.id, 'name': new_task.name, 'is_completed': new_task.is_completed}})
    return jsonify({'error': 'Task name is required'}), 400

# Update task
@app.route('/update_task/<int:task_id>', methods=['POST'])
def update_task(task_id):
    task = Task.query.get_or_404(task_id)
    task_name = request.form.get('name')
    is_completed = request.form.get('is_completed')
    
    if task_name:
        task.name = task_name
    if is_completed is not None:
        task.is_completed = is_completed.lower() == 'true'
    
    db.session.commit()
    return jsonify({'task': {'id': task.id, 'name': task.name, 'is_completed': task.is_completed}})

# Delete task
@app.route('/delete_task/<int:task_id>', methods=['POST'])
def delete_task(task_id):
    task = Task.query.get_or_404(task_id)
    db.session.delete(task)
    db.session.commit()
    return jsonify({'result': 'Task deleted successfully'})

if __name__ == '__main__':
    app.run(debug=True)

